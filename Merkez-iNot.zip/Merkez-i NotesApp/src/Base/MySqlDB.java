package Base;

import static Base.DBHelper.showErrorMessage;
import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.sql.Connection;

public class MySqlDB implements MainDB{
    private Statement STquery;
    private PreparedStatement preparedST;
    private Connection dbConnection;
    public ArrayList<Category> categories;
    public ArrayList<Note> notes;
    public ArrayList<GUISeeming> themes;
    public ArrayList<NoteTag> tags;
    private User user;

    public MySqlDB() {
        //.;.
    }

//İŞLEM YÖNTEMLERİ:
    @Override
    public boolean saveNote(Note note) {
        String strStatementForUpdate;
        strStatementForUpdate = "UPDATE notes SET name'" + note.getName() + "', malumat='" +
                note.getMalumat() + "'";
        try {
            preparedST = DBHelper.getConnection().prepareStatement(strStatementForUpdate);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean saveNoteInfo(int noteID, HashMap<String, Integer> notePageData) {
        return false;
    }

    @Override
    public boolean saveNoteWithNoteInfo(Note note, HashMap<String, Integer> notePageData) {
        return false;
    }

    @Override
    public boolean saveCategory(Category category) {
        return false;
    }

    @Override
    public boolean saveNoteTag(NoteTag tag) {
        return false;
    }

    @Override
    public boolean saveUserInfo(User user) {
        return false;
    }

    @Override
    public boolean saveSysInfo(SysInfo info) {
        return false;
    }

    @Override
    public boolean deleteNote(Note note) {
        return false;
    }

    @Override
    public boolean deleteNoteInfo(Note note) {
        return false;
    }

    @Override
    public boolean deleteCategory(Category category) {
        return false;
    }

    @Override
    public boolean deleteNoteTag(NoteTag tag) {
        return false;
    }

    @Override
    public boolean updateNote(Note note) {
        return false;
    }

    @Override
    public boolean updateNoteInfo(int noteID, HashMap<String, Integer> notePageData) {
        return false;
    }

    @Override
    public boolean updateNoteWithNoteInfo(Note note, HashMap<String, Integer> notePageData) {
        return false;
    }

    @Override
    public boolean updateCategory(Category category) {
        return false;
    }

    @Override
    public boolean updateNoteTag(NoteTag tag) {
        return false;
    }

    @Override
    public boolean updateUserInfo(User user) {
        return false;
    }

    @Override
    public boolean updateSysInfo(SysInfo info) {
        return false;
    }
    //ARKAPLAN İŞLEM YÖNTEMLERİ:
    private boolean addRowToDB(IEntity entity, String tableName){
        //Burada kolon ismini alıp, o isimdeki fonksiyonu çağırmalı
        String sentence = "INSERT INTO " + tableName + " ";
        return false;
    }
    private boolean delRowToDB(IEntity entity, String tableName){
        String sentence = "INSERT INTO " + tableName + " ";
        return false;
    }
    private boolean updRowToDB(IEntity entity, String tableName, String[] fields, String[] values){
        PreparedStatement preStatement;
        //String sentence = "INSERT INTO " + tableName + "(" + ;
        return false;
    }
    public int extractFontStyle(boolean isBold, boolean isItalic){
        if(isBold == true && isItalic == true){
            return 3;
        }
        else if(isBold == true)
            return 1;
        else if(isItalic == true)
            return 2;
        else
            return 0;
    }
    
    public SystemSettings solveSettings(String text){//Çağrılan dosyadan okumalar yaparak ayarları çıkarma
        return SystemSettings.getSettings();
    }
    //VERİ ÇEKME YÖNTEMLERİ:
    public ArrayList<Note> getDBNotes(){
        String ask = new String("select* from notes");
        notes = new ArrayList<Note>();
        ResultSet resultNotes;
        try{
            getSTQuery().clearBatch();
            resultNotes = getSTQuery().executeQuery(ask);
            while(resultNotes.next()){
                Note currentNote;
                currentNote = new Note(resultNotes.getInt("id"),
                        getDBUser(),
                        resultNotes.getString("name"),
                        resultNotes.getString("malumat"),
                        DataBase.getDatabase().findCategoryByID(resultNotes.getInt("Category")),
                        resultNotes.getDate("produceTime"),
                        resultNotes.getDate("lastChangeTime"));
                //currentNote.setTags();
                notes.add(currentNote);
            }
        }
        catch(SQLException DBException){
            showErrorMessage(DBException);
        }
        return notes;
    }
    
    public User getDBUser(){
        String ask = new String("select* from users");
        ResultSet resultUser;
        try{
            resultUser = getSTQuery().executeQuery(ask);
            user = new User(resultUser.getInt("id"),
                    resultUser.getString("name"),
                    resultUser.getString("password"),//şifre aslî hâliyle saklanmamalı!
                    solveSettings(resultUser.getString("settings")));
        }
        catch(SQLException DBException){
            showErrorMessage(DBException);
        }
        return user;
    }
    
    public ArrayList <GUISeeming> getDBThemes(){
        String ask = new String("select* from themes");
        themes = new ArrayList<GUISeeming>();
        ResultSet resultThemes;
        try{
            getSTQuery().clearBatch();
            resultThemes = getSTQuery().executeQuery(ask);
            while(resultThemes.next()){
                themes.add(new GUISeeming(resultThemes.getString("themeName"),
                    resultThemes.getString("backgroundColor"),
                    resultThemes.getString("buttonColor"),
                    resultThemes.getString("buttonTextColor"),
                    resultThemes.getString("buttonOnMouseColor"),
                    resultThemes.getString("buttonTextOnMouseColor"),
                    resultThemes.getString("textColor"),
                    resultThemes.getString("menuColor"),
                    resultThemes.getString("notingAreaColor"),
                    resultThemes.getString("notingAreaTextColor"),
                    resultThemes.getString("notingAreaCursorColor"),
                    resultThemes.getString("notingAreaSelectedColor"),
                    resultThemes.getString("notingAreaSelectedTextColor"),
                    resultThemes.getString("componentBorderColor"),
                    resultThemes.getString("topMenuGroundBackgroundColor"),
                    resultThemes.getString("releasebleMenuTextColor"),
                    resultThemes.getString("releasebleMenuItemColor"),
                    resultThemes.getString("releasebleMenuItemTextColor"),
                    resultThemes.getString("releasebleMenuItemOnMouseColor"),
                    resultThemes.getString("releasebleMenuItemOnMouseTextColor"),
                    resultThemes.getString("editToolsBackgroundColor"),
                    fetchFont(resultThemes.getInt("fontUI"))));
            }
        }
        catch(SQLException DBException){
            showErrorMessage(DBException);
        }
        return themes;
    }
    private ArrayList<Category> getDBCategories(){
        String ask = new String("SELECT * FROM CATEGORIES");
        categories = new ArrayList<Category>();
        ResultSet resultCategories;
        if(categories == null){
            try{
                /*, , , , , 
               , String categoryColor*/
                getSTQuery().clearBatch();
                resultCategories = getSTQuery().executeQuery(ask);
                while(resultCategories.next()){
                    Category category= new Category(resultCategories.getInt("id"),
                            resultCategories.getString("name"),
                            resultCategories.getString("explanation"),
                            resultCategories.getInt("number_of_notes"),
                            resultCategories.getDate("produce_time"),
                            resultCategories.getDate("last_change_time"),
                            resultCategories.getString("categoryColor"));
// ResultSet temp = getDBItemByIDandTable(resultCategories.getInt("image"), "image");
                    //image id alındıktan sonra ArrayList içinde o id ye sâhip olan simgenin geri döndürülmesi gerekir.
                    
                    categories.add(category);
                }
            }
            catch(SQLException DBException){
                showErrorMessage(DBException);
            }
        }
        return categories;
    }
    public Font fetchFont(int id){
        String ask = new String("SELECT fontName, isItalic, isBold, textSize FROM FONTS WHERE ID=" + id);
        ResultSet fontResult;
        try{
            getSTQuery().clearBatch();
            fontResult = getSTQuery().executeQuery(ask);
            return new Font(fontResult.getString("fontName"), extractFontStyle(fontResult.getBoolean("isBold"), 
                    fontResult.getBoolean("isItalic")), fontResult.getInt("fontSize"));
        }
        catch(SQLException DBException){
            showErrorMessage(DBException);
        }
        return null;
    }

//ERİŞİM YÖNTEMLERİ:
    public Statement getSTQuery() {
        if(STquery == null){
            try{
                STquery = DBHelper.getConnection().createStatement();
            }
            catch(SQLException DBException){
                DBHelper.showErrorMessage(DBException);
            }
        }
        return STquery;
    }
    public void setSTquery(Statement STquery) {
        this.STquery = STquery;
    }

    @Override
    public boolean installSystem(String code, DataBase database) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Category> readCategories() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Note> readNotes() {
        return new ArrayList<Note>();
    }

    @Override
    public ArrayList<NoteTag> readNoteTags() {
        return new ArrayList<NoteTag>();
    }

    @Override
    public SysInfo readSysInfo(String code) {
        return null;
    }

    @Override
    public User readUserInfo() {
        return null;
    }

    @Override
    public HashMap<Integer, HashMap> readNotePageData() {
        return new HashMap<Integer, HashMap>();
    }
    @Override
    public boolean backupSystem(String code, String path, boolean isCryot) {
        //.;.
        return false;
    }
}
