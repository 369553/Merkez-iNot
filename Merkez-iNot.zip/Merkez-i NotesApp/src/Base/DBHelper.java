package Base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBHelper {
    private static String dbUrl = "jdbc:mysql://localhost:3306/test";
    private static String userName = "root";
    private static String secret = "LINQSE.1177";
    private static Connection connext;
    private static Statement STquery;
    
    public static Connection getConnection(){
        if (connext == null){
            try{
                connext = DriverManager.getConnection(dbUrl, userName, secret);
                System.out.println("Bağlantı kuruldu");
                return connext;
            }
            catch(SQLException DBException){
                showErrorMessage(DBException);
                return null;
            }
        }
        return connext;
    }
    public static boolean FinishConnection(){//VERİTABANI İŞLEMLERİ SINGLETON KURALINA UYGUN OLARAK YAPILMALI
        if(connext !=  null){
            try{
                connext.close();
                return true;
            }
            catch(SQLException DBException){
                showErrorMessage(DBException);
                return false;
            }
        }
            System.err.println("Bağlantı kurulmamış!");
            return true;
    }
    
    public static void showErrorMessage(SQLException DBException){//BURASI GELİŞTİRİLEBİLİR, HATALAR DAHA İYİ YÖNETİLEBİLİR Bİ İZNİLLÂH
        System.out.println(DBException.getErrorCode() + "\n" + DBException.getMessage());
    }
    
    public static Statement getSTQuery(){
        if(STquery == null){
            try{
                STquery = getConnection().createStatement();
            }
            catch(SQLException DBException){
                showErrorMessage(DBException);
            }
        }
        return STquery;
    }
}
