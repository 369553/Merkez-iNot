package Base;

public interface IEntity {
    
    
}
