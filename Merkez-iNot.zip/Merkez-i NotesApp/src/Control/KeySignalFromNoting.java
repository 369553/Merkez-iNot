
package Control;

import View.EditingPanel;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeySignalFromNoting implements KeyListener{
    EditingPanel editPanel;

    public KeySignalFromNoting(EditingPanel panel){
        this.editPanel = panel;
    }

//İŞLEM YÖNTEMLERİ:
    @Override
    public void keyTyped(KeyEvent e) {
        if(editPanel != null){
            if(e.getSource() == editPanel.getTextArea_writingArea()){
                //Herhangi bir tuşa basıldığında değil; sadece içerik değiştiğinde kaydetme işlevi aktif olmalı
    //            System.out.println("kod : " + (int) e.getKeyChar());
    //            System.err.println("basılan tuş: " + e.getKeyChar());
             //   System.out.println("yazı : " + editPanel.getTextArea_writingArea().getText());
                editPanel.isChanged = true;
                editPanel.updateForChangeAnyThing();
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getSource() == editPanel.getTextArea_writingArea()){
            /*if(e.getKeyChar() == ' '){
                if(!(editPanel.getTextArea_writingArea().getText().charAt(e.getKeyLocation() - 1) == ' ')){
                    editPanel.getCpSystem().addNewCheckPoint(editPanel.getTextArea_writingArea().getText());
                }
            }*/
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    //TUŞ BIRAKILDIĞINDA
    }
}