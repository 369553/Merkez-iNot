package Services;

import Control.IDARE;

public class CryptingService {
    private static CryptingService servicer = null;

    private CryptingService() {
    
    }
    
//İŞLEM YÖNTEMLERİ:
    public static String getMd5(String text){
        //.;.
        return IDARE.getMd5Code();
    }
    
//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static CryptingService getServicer(){
        if(servicer == null){
            servicer = new CryptingService();
        }
        return servicer;
    }
}
