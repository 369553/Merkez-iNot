package View;

import java.awt.Dimension;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.NO_OPTION;
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;


public class InteractiveGUIStructs {
    int interTypeActive = 0;
    private static InteractiveGUIStructs activeManager;
    MainPanel MP;
    
    public InteractiveGUIStructs(MainPanel MP) {
        this.MP = MP;
    }
    
//İŞLEM YÖNTEMLERİ:
    public String showJustTextField(String topText, String message){ //topText = Üst başlık, message = Gösterilmek istenen yardımcı yazı
        String value = JOptionPane.showInputDialog(MP, message, topText, QUESTION_MESSAGE);
        return value;
    }
    public void showNotAcceptableError(String errorMessage){
        JOptionPane.showMessageDialog(MP, errorMessage);
    }
    public boolean showYesNoQuestion(String questionText, String titleText){
        int value = JOptionPane.showConfirmDialog(MP, questionText, titleText, JOptionPane.YES_NO_OPTION);
        if(value == 0)
            return true;
        return false;
    }
    public int showYesNoCancelQuestion(String queestionText, String titleText){
        return JOptionPane.showConfirmDialog(MP, queestionText, titleText, JOptionPane.YES_NO_CANCEL_OPTION, QUESTION_MESSAGE);
    }
    public void showYesNoQuestion(String questionText){
        Object value = JOptionPane.showConfirmDialog(MP, questionText);
        System.out.println("value : " + (int) value);
    }
    public void showSuccesfulOperationMessage(String message){
        JOptionPane.showMessageDialog(MP, message, "İşlem başarılı!", INFORMATION_MESSAGE);
    }
    
    public int showSpecialGUI(JComponent panel, String topText, String message){
    /*    GUISeeming.appGUI(panel); // Burada bu işlem yapılırsa not rengiyle ilgili panel de arkaplan rengine boyanıyor;
        O yüzden gönderilen panlein gönderilmeden evvel arayüz boyamasının yapılması gerekiyor.*/
        int value = JOptionPane.showOptionDialog(MP, message, topText, NO_OPTION, QUESTION_MESSAGE,
                null/*Simge yok*/, new Object[]{panel}, null);
        return value;
    }
    
    public int showSpecialGUI(JComponent panel, String topText, String message, int width, int height){
        panel.setSize(width, height);
        panel.setPreferredSize(new Dimension(width, height));
        return showSpecialGUI(panel, topText, message);
    }
    
    public static void startActiveManager(MainPanel MP){
        if(activeManager == null)
            activeManager = new InteractiveGUIStructs(MP);
    }
    
/*YARIM KALDI    public JComponent prepareSpecialPanelForChoosing (String componentTypeName, Object[] data){
        switch(componentTypeName){
            case "JList":{
                
                break;
            }
            case "JComboBox":{
                
                break;
            }
            case "JPanel":{
                
                break;
            }
        }
        return null;
    }*/
    
//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static InteractiveGUIStructs getActiveManager() {
        return activeManager;
    }

    public static void setActiveManager(InteractiveGUIStructs activeManager) {
        InteractiveGUIStructs.activeManager = activeManager;
    }
    
    
}