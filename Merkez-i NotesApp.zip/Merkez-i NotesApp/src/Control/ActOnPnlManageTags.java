package Control;

import Base.DataBase;
import Base.Note;
import View.PnlManageTags;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ActOnPnlManageTags implements ActionListener, ListSelectionListener{
    PnlManageTags pnl;
    Color clrSelectedBackground, clrSelectedForeground;

    public ActOnPnlManageTags(PnlManageTags pnl) {
        this.pnl = pnl;
    }

//İŞLEM YÖNTEMLERİ:
    @Override
    public void actionPerformed(ActionEvent e) {
        if(pnl != null){
            if(e.getSource() == pnl.getBtnRemoveTag()){//Etiket kaldır
                if(pnl.getLiTagNotes().getSelectedValuesList().isEmpty())
                    return;
                String[] strSelectedValues = new String[pnl.getLiTagNotes().getSelectedValuesList().size()];
                for(int index = 0; index < strSelectedValues.length; index++){
                    strSelectedValues[index] = pnl.getLiTagNotes().getSelectedValuesList().get(index);
                }
                for(int index = 0; index < strSelectedValues.length; index++){
                    Note temp = DataBase.getDatabase().getNoteByName(strSelectedValues[index].split(":")[0].trim(),
                            strSelectedValues[index].split(" : ")[1].trim());
                    if(temp != null){
                        if(pnl.getChoosedTag() != null){
                            temp.removeTag(pnl.getChoosedTag());
                            pnl.refreshLiTagNotes();
                        }
                    }
                }
            }
            else if(e.getSource() == pnl.getBtndeleteTag()){//Etiketi sil
                if(pnl.getChoosedTag()!= null){
                    if(IDARE.deleteNoteTagFromSys(pnl.getChoosedTag())){
                        pnl.refreshLiTags();
                        pnl.refreshLiTagNotes();
                    }
                }
            }
            else if(e.getSource() == pnl.getBtnAddTagToNotes()){//Etiketi notlara ekle
                if(pnl.getChoosedTag()!= null){
                    if(pnl.getLiNotes().getSelectedValuesList().isEmpty())
                        return;
                    String[] strSelectedValues = new String[pnl.getLiNotes().getSelectedValuesList().size()];
                    for(int index = 0; index < strSelectedValues.length; index++){
                        strSelectedValues[index] = pnl.getLiNotes().getSelectedValuesList().get(index);
          //              System.out.println(": " + strSelectedValues[index]);
                    }
                    for(int index = 0; index < strSelectedValues.length; index++){
                        Note temp = DataBase.getDatabase().getNoteByName(strSelectedValues[index].split(":")[0].trim(),
                                strSelectedValues[index].split(" : ")[1].trim());
                        if(temp != null){
                            temp.addTag(pnl.getChoosedTag());
                        }
                    }
                    pnl.chooseTag();
                }
            }
        }
        return;
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
    //    System.err.println("Sinyal geldi bi iznillâh");
        if(e.getSource() == pnl.getLiTags()){
            pnl.chooseTag();
        }
    }
}
